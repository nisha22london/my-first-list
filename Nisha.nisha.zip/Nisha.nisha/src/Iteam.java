
public class Iteam {
	private long id;
	private String Name; 
	private long Value;

	public Iteam (long id, String Name,long value);

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public long getValue() {
		return Value;
	}

	public void setValue(long value) {
		Value = value;
	}
	this.id = id;
	this.Name = Name;
	this.value = value;
	
	
	
	

)

